<?php

?>
<option>Accounting , Finance</option>
<option>Advertising , PR , MR , Event Management</option>
<option>Agriculture , Dairy</option>
<option>Animation , Gaming</option>
<option>Architecture , Interior Design</option>
<option>Automobile , Auto Anciliary , Auto Components</option>
<option>Aviation , Aerospace Firms</option>
<option>Banking , Financial Services , Broking</option>
<option>BPO , Call Centre , ITES</option>
<option>Brewery , Distillery</option>
<option>Broadcasting</option>
<option>Ceramics , Sanitary ware</option>
<option>Chemicals , PetroChemical , Plastic , Rubber</option>
<option>Construction , Engineering , Cement , Metals</option>
<option>Consumer Electronics , Appliances , Durables</option>
<option>Courier , Transportation , Freight , Warehousing</option>
<option>Education , Teaching , Training</option>
<option>Electricals , Switchgears</option>
<option>Export , Import</option>
<option>Facility Management</option>
<option>Fertilizers , Pesticides</option>
<option>FMCG , Foods , Beverage</option>
<option>Food Processing</option>
<option>Fresher , Trainee , Entry Level</option>
<option>Gems , Jewellery</option>
<option>Glass , Glassware</option>
<option>Government , Defence</option>
<option>Heat Ventilation , Air Conditioning</option>
<option>Industrial Products , Heavy Machinery</option>
<option>Insurance</option>
<option>Internet , Ecommerce</option>
<option>Iron and Steel</option>
<option>IT-Hardware & Networking</option>
<option>IT-Software , Software Services</option>
<option>KPO , Research , Analytics</option>
<option>Leather</option>
<option>Legal</option>
<option>Media , Entertainment , Internet</option>
<option>Medical , Healthcare , Hospitals</option>
<option>Medical Devices , Equipments</option>
<option>Mining , Quarrying</option>
<option>NGO , Social Services , Regulators , Industry Associations</option>
<option>Office Equipment , Automation</option>
<option>Oil and Gas , Energy , Power , Infrastructure</option>
<option>Other</option>
<option>Pharma , Biotech , Clinical Research</option>
<option>Printing , Packaging</option>
<option>Publishing</option>
<option>Pulp and Paper</option>
<option>Real Estate , Property</option>
<option>Recruitment , Staffing</option>
<option>Retail , Wholesale</option>
<option>Security , Law Enforcement</option>
<option>Semiconductors , Electronics</option>
<option>Shipping , Marine</option>
<option>Strategy , Management Consulting Firms</option>
<option>Sugar</option>
<option>Telecom,ISP</option>
<option>Textiles , Garments , Accessories</option>
<option>Travel , Hotels , Restaurants , Airlines , Railways</option>
<option>Tyres</option>
<option>Water Treatment , Waste Management</option>
<option>Wellness , Fitness , Sports, Beauty</option>

